<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Edit Medicine Form</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Edit Medicine</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
  
    <!-- Main content -->
    <section class="content">
        <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title">Edit Medicine</h3>
            </div>
            <div class="editMedicineForm">
                <form id="MedicineForm" action="<?php echo e(route("dashboard.update.medicine")); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body row">
                        <div class="form-group col-md-6">
                            <label for="exampleInputName">Medicine Name</label>
                            <input name="medicine_name" type="text" id="medicine_name" class="form-control" value="<?php echo e($medicine->medicine_name); ?>" id="name" placeholder="Enter medicine name" required>
                            <span id="medicineNameError" style="color: red;"></span>
                            <?php $__errorArgs = ['medicine_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <input type="text" name="id" value="<?php echo e($medicine->id); ?>" hidden>
                        <div class="form-group col-md-6">
                            <label>Manufacturer Name</label>
                            <select name="manufacturer_id" class="form-control select2bs4" style="width: 100%;" required>
                                <option value="" selected="selected" disabled>Select Manufacturer Name</option>
                                <?php $__currentLoopData = $companys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($c->id == null): ?>
                                        <option value="" disabled>No Manufacturer</option>
                                    <?php else: ?>
                                        <option value="<?php echo e($c->id); ?>" <?php echo e(old('manufacturer_id', $medicine->manufacturer_id ) == $c->id ? 'selected' : ''); ?>>
                                            <?php echo e($c->name); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['manufacturer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger">Group Manufacturer Name Required</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Brand Name</label>
                            <select name="brand_id" class="form-control select2bs4" style="width: 100%;" required>
                                <option value="" selected="selected" disabled>Select Brand Name</option>
                                <?php $__currentLoopData = $companys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($c->id == null): ?>
                                        <option value="" disabled>No Brand</option>
                                    <?php else: ?>
                                        <option value="<?php echo e($c->id); ?>" <?php echo e(old('brand_id', $medicine->brand_id ) == $c->id ? 'selected' : ''); ?>>
                                            <?php echo e($c->name); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['group_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger">Brand Name Required</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputName">Use For</label>
                            <input name="use_for" type="text" id="use_for" class="form-control" value="<?php echo e($medicine->use_for); ?>" id="use_for" placeholder="Enter use for" required>
                            <?php $__errorArgs = ['use_for'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputName">Price</label>
                            <input name="price" type="number" id="price" class="form-control" value="<?php echo e($medicine->price); ?>" id="price" placeholder="Enter price" required>
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Group Name</label>
                            <select name="group_id" class="form-control select2bs4" style="width: 100%;" required>
                                <option value="" selected="selected" disabled>Select Group Name</option>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($g->id == null): ?>
                                        <option value="" disabled>No Group</option>
                                    <?php else: ?>
                                        <option value="<?php echo e($g->id); ?>" <?php echo e(old('group_id', $medicine->group_id) == $g->id ? 'selected' : ''); ?>>
                                            <?php echo e($g->group_name); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['group_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger">Group Name Required</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group col-md-6">
                            <label for="exampleInputName">Strength</label>
                            <input name="strength" type="text" class="form-control" value="<?php echo e($medicine->strength); ?>" id="strength" placeholder="Enter strength example: 10mg" required>
                            <?php $__errorArgs = ['power'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Medicine Type</label>
                            <select name="type_id" class="form-control select2bs4" style="width: 100%;" required>
                                <option value="" class="text-muted" selected="selected" disabled>Select Medicine Type</option>
                                <?php $__currentLoopData = $medicineTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($type->id == null): ?>
                                        <option value="" disabled>No Type</option>
                                    <?php endif; ?>
                                    <option value="<?php echo e($type->id); ?>" <?php echo e(old('type_id', $medicine->type_id) == $type->id ? 'selected' : ''); ?>>
                                        <?php echo e($type->type_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger">Medicine Type Required</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Status</label>
                            <select name="status" class="form-control " style="width: 100%;" required>
                              <option value="" selected="selected">Select Status</option>
                              <option value="active" <?php echo e($medicine->status == 'active' ? 'selected' : ''); ?>>Active</option>
                              <option value="inactive" <?php echo e($medicine->status == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                        <div class="form-group col-md-12">
                            <label for="exampleInputName">Medicine Description</label>
                            <textarea name="description" class="form-control" placeholder="Enter description" required><?php echo e($medicine->description); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="card-footer col-md-12 justify-content-between">
                        <button type="button" class="btn btn-secondary" onclick="window.location.href='<?php echo e(url('dashboard/medicine-list')); ?>'">Cancel</button>
                        <button type="submit" class="btn btn-primary float-right">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>

  <script>
    $(function () {
        //Initialize Select2 Elements
        $('.select2').select2();
        $('.select2bs4').select2({
      theme: 'bootstrap4'
    })
    });
</script>


<?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/medicine/edit-medicine.blade.php ENDPATH**/ ?>
<!-- Create admin Modal -->
<div class="modal fade" id="createPatienVendor" tabindex="-1" role="dialog" aria-labelledby="createPatienVendorModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-info">
                <h5 class="modal-title" id="createPatienVendorModalLabel">Create Patien Vendor</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Include your form here -->
                <form id="createPatienVendorForm" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body row">
                        <div class="form-group col-md-6">
                            <label for="exampleInputName">Name</label>
                            <input name="name" type="text" class="form-control" value="<?php echo e(old('name')); ?>" id="name" placeholder="Enter name" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                
                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1">Email address</label>
                            <input name="email" type="email" class="form-control" value="<?php echo e(old('email')); ?>" id="email" placeholder="Enter email" required>
                            <span id="email-availability-status"></span>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                
                        <div class="form-group col-md-6">
                          <label for="exampleInputMobile">Mobile Number</label>
                          <div class="input-group">
                              <div class="input-group-prepend">
                                  <span class="input-group-text">+88</span>
                              </div>
                              <input name="phone" type="number" class="form-control" value="<?php echo e(old('phone')); ?>" id="phone" placeholder="Enter mobile" required>
                          </div>
                          <span id="result"></span>
                          <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <p class="text-danger"><?php echo e($message); ?></p>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputPassword1">FAX</label>
                            <input name="fax" type="number" class="form-control" id="fax" value="<?php echo e(old('fax')); ?>" placeholder="Enter fax" >
                            <?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputPassword1">Address</label>
                            <input name="address" type="text" class="form-control" id="address" value="<?php echo e(old('address')); ?>" placeholder="Enter address" required>
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputPassword1">Contact Person</label>
                            <input name="contact_person" type="text" class="form-control" id="contact_person" value="<?php echo e(old('contact_person')); ?>" placeholder="Enter contact person" required>
                            <?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="card-footer col-md-12 justify-content-between">
                        <button type="button" class="close float-left" data-dismiss="modal" aria-label="Close" ><span class="btn btn-dark" aria-hidden="true">Cancel</span></button>
                        <button type="submit" class="btn btn-primary float-right" id="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#createPatienVendorForm').on('submit', function(event) {
            event.preventDefault();

            $.ajax({
                url: '<?php echo e(route('dashboard.create-patient-vandor')); ?>',
                method: 'POST',
                data: $(this).serialize(),
                success: function(response) {
                    if(response.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message,
                        });
                        setTimeout(function() {
                            window.location.href = '<?php echo e(route('dashboard.patient-vandor-list')); ?>';
                        }, 2000);
                    } 
                    else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message,
                        });
                    }
                },
                error: function(xhr) {
                    // Handle validation or server errors
                    let errorMessage = '';

                    if (xhr.status === 422) { // Laravel validation errors
                        const errors = xhr.responseJSON.errors;
                        errorMessage = Object.values(errors).map(function(error) {
                            return error.join(' '); // Combine all error messages into a single string
                        }).join('<br>');
                    } else if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message; // Custom exception message from Laravel
                    } else {
                        errorMessage = 'An unexpected error occurred. Please try again later.';
                    }

                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        html: errorMessage, // Use 'html' instead of 'text' to display line breaks
                    });
                }
            });
        });
    });
</script>



  <?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/patient_vendors/create-vandor.blade.php ENDPATH**/ ?>
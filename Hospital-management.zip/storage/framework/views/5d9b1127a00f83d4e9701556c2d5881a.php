<div class="row">
	<!-- Admin -->
	<!-- Patient -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-info">
			<div class="inner">
				<h3><?php echo e($patientCount); ?></h3>
				<p>Total Patient</p>
			</div>
			<div class="icon">
				<i class="ion ion-person-add"></i>
			</div>
			<a href="<?php echo e(url("dashboard/patient-list")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	
	<!-- active Doctor -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-success">
			<div class="inner">
				<h3><?php echo e($activePatientCount); ?></h3>
				<p>Active Patient</p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-user-doctor"></i>
			</div>
			<a href="<?php echo e(url("dashboard/active-patient")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
    
    <div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box" style="background: yellow">
			<div class="inner">
				<h3><?php echo e($inActivePatientCount); ?></h3>
				<p>Inactive Patient</p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-user-doctor"></i>
			</div>
			<a href="<?php echo e(url("dashboard/inactive-patient")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<!-- Patient -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-danger">
			<div class="inner">
				<h3><?php echo e($deletedPatientCount); ?></h3>
				<p>Deleted Patient</p>
			</div>
			<div class="icon">
				<i class="ion ion-person-add"></i>
			</div>
			<a href="<?php echo e(url("dashboard/deleted-patient")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<!-- Today Patient -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-success">
			<div class="inner">
				<h3><?php echo e($todayPatientCount); ?></h3>
				<p>Today Registered <br> Patient </p>
			</div>
			<div class="icon">
				<i class="ion ion-person-add"></i>
			</div>
		</div>
	</div>
	<!-- ./col -->
</div><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/dashboard/count/patient.blade.php ENDPATH**/ ?>
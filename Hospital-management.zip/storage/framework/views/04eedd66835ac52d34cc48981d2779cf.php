
<div class="modal fade" id="createMedicine" tabindex="-1" role="dialog" aria-labelledby="createMedicineModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-info">
                <h5 class="modal-title" id="createMedicineModalLabel">Create Medicine</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="createMedicineForm" action="<?php echo e(route("dashboard.create.medicine")); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body row">
                        <div class="form-group col-md-6">
                            <label for="exampleInputName">Medicine Name</label>
                            <input name="medicine_name" type="text" id="medicine_name" class="form-control" value="<?php echo e(old('medicine_name')); ?>" id="name" placeholder="Enter medicine name" required>
                            <span id="medicineNameError" style="color: red;"></span>
                            <?php $__errorArgs = ['medicine_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Manufacturer Name</label>
                            <select name="manufacturer_id" class="form-control select2bs4" style="width: 100%;" required>
                                <option value="" selected="selected" disabled>Select Manufacturer</option>
                                <?php $__currentLoopData = $companys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($c->id == null): ?>
                                        <option value="" disabled>No Manufacturer</option>
                                    <?php else: ?>
                                    <option value="<?php echo e($c->id); ?>" <?php echo e(old('group_id') == $c->id ? 'selected' : ''); ?>>
                                        <?php echo e($c->name); ?>

                                    </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['manufacturer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger">Manufacturer Name Required</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Brand Name</label>
                            <select name="brand_id" class="form-control brand" style="width: 100%;" required>
                                <option value="" selected="selected" disabled>Select Brand Name</option>
                                <?php $__currentLoopData = $companys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($c->id == null): ?>
                                        <option value="" disabled>No Brand</option>
                                    <?php else: ?>
                                    <option value="<?php echo e($c->id); ?>" <?php echo e(old('brand_id') == $c->id ? 'selected' : ''); ?>>
                                        <?php echo e($c->name); ?>

                                    </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger">Brand Name Required</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputName">Use For</label>
                            <input name="use_for" type="text" id="use_for" class="form-control" value="<?php echo e(old('use_for')); ?>" id="use_for" placeholder="Enter use for" required>
                            <?php $__errorArgs = ['use_for'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputName">Price</label>
                            <input name="price" type="number" id="price" class="form-control" value="<?php echo e(old('price')); ?>" id="price" placeholder="Enter price" required>
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Group Name</label>
                            <select name="group_id" class="form-control group" style="width: 100%;" required>
                                <option value="" selected="selected" disabled>Select Group Name</option>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($g->id == null): ?>
                                        <option value="" disabled>No Group</option>
                                    <?php else: ?>
                                    <option value="<?php echo e($g->id); ?>" <?php echo e(old('group_id') == $g->id ? 'selected' : ''); ?>>
                                        <?php echo e($g->group_name); ?>

                                    </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['group_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger">Group Name Required</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group col-md-6">
                            <label for="exampleInputName">Strength</label>
                            <input name="strength" type="text" class="form-control" value="<?php echo e(old('strength')); ?>" id="strength" placeholder="Example: 10mg" required>
                            <?php $__errorArgs = ['power'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Medicine Type</label>
                            <select name="type_id" class="form-control type-search" style="width: 100%;" required>
                                <option value="" ></option>
                                <?php $__currentLoopData = $medicineTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($type->id == null): ?>
                                        <option value="" disabled>No Type</option>
                                    <?php endif; ?>
                                    <option value="<?php echo e($type->id); ?>" <?php echo e(old('type_id') == $type->id ? 'selected' : ''); ?>>
                                        <?php echo e($type->type_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger">Medicine Type Required</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group col-md-12">
                            <label for="exampleInputName">Medicine Description</label>
                            <textarea name="description" class="form-control" placeholder="Enter description" required><?php echo e(old('description')); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                    </div>
                    <div class="card-footer col-md-12 justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success float-right" id="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
    $(document).ready(function() {
    $('.brand').select2({
        placeholder: "---Select Brand---",
        allowClear: true,
        theme: 'bootstrap4'
    });

    });
    $(document).ready(function() {
    $('.group').select2({
        placeholder: "---Select Group---",
        allowClear: true,
        theme: 'bootstrap4'
    });

    });
    $(document).ready(function() {
        $('.type-search').select2({
            placeholder: "---Select Type---",
            allowClear: true,
            theme: 'bootstrap4'
        });
    });
</script>

  <script type="text/javascript">
    $(document).ready(function() {
        $('#medicine_name').on('keyup', function() {
            var medicineName = $(this).val();
            $.ajax({
                url: '<?php echo e(route("dashboard.check.medicine-name")); ?>',
                type: 'GET',
                data: { medicine_name: medicineName },
                success: function(response) {
                    if (response.exists) {
                        $('#medicineNameError').text('This medicine name is already taken.');
                        $('#submit').attr('disabled', true);
                    } else {
                        $('#medicineNameError').text('');
                        $('#submit').attr('disabled', false);
                    }
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function () {
        $('#createMedicineForm').on('submit', function (e) {
            e.preventDefault(); 
    
            var formData = new FormData(this); 
    
            $.ajax({
                url: $(this).attr('action'), 
                type: 'POST',
                data: formData,
                processData: false, 
                contentType: false, 
                success: function (response) {
                    
                    if(response.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: response.message,
                            });
                            setTimeout(function() {
                                window.location.href = '<?php echo e(route('dashboard.medicine-list')); ?>';
                            }, 2000);
                    } 
                },
                error: function (xhr) {
                    var errors = xhr.responseJSON.errors;
                    $('.text-danger').remove(); 
    
                    if (errors) {
                        $.each(errors, function (key, value) {
                            var inputField = $('[name="' + key + '"]');
                            inputField.after('<span class="text-danger">' + value[0] + '</span>');
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: xhr.responseJSON.message || 'Something went wrong!',
                            confirmButtonText: 'OK'
                        });
                    }
                }
            });
        });
    });
    </script>
    
    


<?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/medicine/create-medicine.blade.php ENDPATH**/ ?>
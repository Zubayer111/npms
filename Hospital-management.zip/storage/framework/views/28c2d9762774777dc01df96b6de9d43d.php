
<style>
    @media print {
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 0 auto;
    }
    td, th {
        padding: 3px; /* Reduce padding */
        word-wrap: break-word;
    }
}
@media print {
    body {
        font-size: 11px; /* Slightly smaller font size */
    }
    pre {
        white-space: normal; /* Prevent long content from breaking layout */
    }
}
@media print {
    #print-prescription, table, tr, td {
        page-break-inside: avoid;
    }
    h3, h5, p {
        margin: 0; /* Reduce spacing */
    }
}
@media print {
    body, html {
        margin: 0;
        padding: 0;
    }
}
@media print {
    #print-prescription {
        transform: scale(0.95); /* Adjust scale to fit */
        transform-origin: top left;
    }
}

</style>

<div class="content-wrapper">
      <section class="content">
        <input class="btn btn-success" type="button" onclick="printDiv('print-prescription')" value="Print" />
<div id="print-prescription" class="avoid-page-break">
    <table border="0" cellpadding="10" cellspacing="10" style="width: 100%">
        <tr style="border: solid 1px">
            <p>
                <h3 style="text-align: center;height: auto; margin-top: 0px">
                    بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ 
                </h3>
            </p>
            <td colspan="6" style="text-align: center; height: auto;"><h3>Your Hospatel Name</h3>
            <h5>Your Hospatel Address</h5>
            </td>
        </tr>
        
        <tr style="border: solid 0px">
            
            <td colspan="2" style="text-align: left; ">
                    <h3 class="text-start mb-2 text-bold">DR. <?php echo e($doctor->first_name); ?> <?php echo e($doctor->middle_name); ?>  <?php echo e($doctor->last_name); ?></h3>
                    <p class="m-auto"><?php echo e($doctor->degree ?? "No user data available"); ?></p>
                    <p class="m-auto"><?php echo e($doctor->speciality ?? "No user data available"); ?></p>
                    <p class="m-auto"><?php echo e($doctor->organization ?? "No user data available"); ?></p>
                    <p class="m-auto"><?php echo e($doctor->address_one ?? "No user data available"); ?></p>
                
            </td>
            
            </td>
            
        </tr>
        <tr style="border: solid 1px ">
            <td style="padding: 2px; font-size: x-large;"><strong><?php echo e($patient->title); ?> <?php echo e($patient->first_name); ?> <?php echo e($patient->middle_name); ?>  <?php echo e($patient->last_name); ?> </strong></td>
            <td></td><td></td>
            <td><strong>Age: <?php echo e($age); ?> </strong>Years</td>
            
            <td style="text-align: right; padding: 5px;" > <strong> Date:</strong> <?php echo e($formattedDate); ?> </td>
        </tr>
        <tr  valign="top">
      	            <td style="border: solid 1px; padding: 5px; width: 290px;">
                <table cellpadding="5" cellspacing="5">
                    
                      <tr>
                         <td>
                            <strong style="border-bottom: solid 1px;">PATIENT DETAILS</strong>
                            <p style="padding-top: 5px; font-size: larger; text-align: justify-all;"><?php echo e($patient->gender); ?>,
                                <?php echo e($patient->phone_number); ?>, <?php echo e($patient->address_one); ?></p>
                        </td>
                     </tr>

                        <tr>
                        <td>
                            <strong style="border-bottom: solid 1px;">D/D</strong>
                            <p style="padding-top: 10px; font-size: smaller; text-align: justify-all;"><?php echo e($advice->disease_description ?? "N/A"); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong style="border-bottom: solid 1px;">C/D</strong>
                            <p style="padding-top: 10px; font-size: smaller; text-align: justify-all;"><?php echo e($advice->clinical_diagnosis ?? "N/A"); ?></p>
                        </td>
                    </tr>
										
                    <tr>
                        <td>
                            <strong style="border-bottom: solid 1px;">ADVICE</strong>
                            <p style="padding-top: 1px"><pre style="display: block;margin: 0 0 10px;font-size: smaller; text-align: justify-all; color: #333;background-color: #FFF;border: 0px;"><?php echo e($advice->advice ?? "N/A"); ?></pre></p>
                        </td>
                    </tr>
					
					<tr>
                        <td>
                            <strong style="border-bottom: solid 1px;">INVESTIGATION</strong>
                            <p style="padding-top: 1px"><pre style="display: block;margin: 0 0 10px;font-size: smaller; text-align: justify-all; color: #333;background-color: #FFF;border: 0px;;"><?php echo e($advice->investigation ?? "N/A"); ?></pre></p>
                        </td>
                    </tr>
					<tr>
                        <td>
                            <strong style="border-bottom: solid 1px;">GUIDE TO PREVIOUS PRESCRIPTION</strong>
                            <p style="padding-top: 1px;"><pre style="display: block;margin: 0 0 10px;font-size: smaller; text-align: justify-all; color: #333;background-color: #FFF;border: 0px;"><?php echo e($advice->guide_to_prescription ?? "N/A"); ?></pre></p>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                </table>
            </td>
            <td style="border: solid 1px; padding: 10px" colspan="4">
                <P>
                    <span style="font-size: 25px; font-family: MingLiU_HKSCS-ExtB">M</span>t
                </p>
                <table cellpadding="5" cellspacing="5">
                    <?php $__currentLoopData = $prescriptionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="border-right: solid 1px; padding: 10px"><?php echo e($loop->iteration); ?> .</td>
                        <td style="padding: 3px; font-size: medium;">
                            
                            <p>
                                <span style="font-size: 17px;">
                                    <?php echo e($medicine->medicine_name); ?>

                                </span>
                            </p>
                            <p>
                               <span style="font-size: 13px;"> 
                                <?php echo e($medicine->dose); ?> 
                        </span>
                        </p>
                        </td>
                        <td style="padding: 10px; width: 70px;text-align: right;"><?php echo e($medicine->duration); ?></td>
                        <td style="padding: 10px; width: 200px; text-align: justify-all;font-size: small;"><?php echo e($medicine->duration_unit); ?></td>
                       <!-- diet chart-->
                         <td style="padding: 10px; width: auto; text-align: justify;"><?php echo e($medicine->instruction); ?></td> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </td>
        </tr>
        <tr>
            <td style="text-align: left;padding-top: 5px">Next Meeting Date:<?php echo e($advice->next_meeting_date ?? "N/A"); ?></td>
            <td colspan="0" style="text-align: center; padding-top: 5px">Powered By NPMS</td>
            <td style="text-align: right;padding-top: 5px" colspan="3">বিঃ দ্রঃ-পরবর্তী প্রয়োজনে ব্যবস্থাপত্র সংরক্ষণ করুন। </td>
                    </tr>
    </table>
</div>
      </section>
</div>


<script>
    function printDiv(divName) {
         var printContents = document.getElementById(divName).innerHTML;
         var originalContents = document.body.innerHTML;
    
         document.body.innerHTML = printContents;
    
         window.print();
    
         document.body.innerHTML = originalContents;
    }
</script>
<?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/prescriptions/table/prescription.blade.php ENDPATH**/ ?>
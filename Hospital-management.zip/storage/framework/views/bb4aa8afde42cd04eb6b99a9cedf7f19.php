

<?php $__env->startSection("content"); ?>
  <?php echo $__env->make("backend.components.dashboard.top-nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if(session('type') == 'Admin'): ?>
  <?php echo $__env->make("backend.components.dashboard.side-nav.admin_nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php elseif( session('type') == 'Company'  ): ?>
  <?php echo $__env->make("backend.components.dashboard.side-nav.company_nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php elseif( session('type') == 'Doctor'): ?>
  <?php echo $__env->make("backend.components.dashboard.side-nav.doctor_nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php elseif( session('type') == 'Patient'): ?>
  <?php echo $__env->make("backend.components.dashboard.side-nav.patient_nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php echo $__env->yieldContent("page_content"); ?>

  <?php echo $__env->make("backend.components.dashboard.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("backend.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/layouts/sidenav-layout.blade.php ENDPATH**/ ?>
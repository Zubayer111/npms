<table class="table table-responsive table-sm table-bordered">
    <thead>
        <tr>
            <th>SL</th>
            <th>Medicine</th>
            <th>Dose</th>
            <th>Duration</th>
            <th>Instruction</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody id="medicineList">
        <?php $__empty_1 = true; $__currentLoopData = $allPrescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($m->medicine_name); ?></td>
            <td><?php echo e($m->dose); ?></td>
            <td><?php echo e($m->duration); ?></td>
            <td><?php echo e($m->instruction); ?></td>
            <td>
                <a href="#" class="delete-medicine" data-id="<?php echo e($m->id); ?>">
                    <i class="glyphicon glyphicon-trash"></i>
                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6" class="text-center">No medicines added.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/prescriptions/medicine-list.blade.php ENDPATH**/ ?>
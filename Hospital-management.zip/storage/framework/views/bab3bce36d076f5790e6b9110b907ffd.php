<div class="row">
	<!-- Admin -->
	<div class="col-lg-3 col-6">
		<div class="small-box bg-info">
			<div class="inner">
				<h3><?php echo e($doctorCount); ?></h3>
				<p>Total Doctor</p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-user-doctor"></i>
			</div>
			<a href="<?php echo e(url("dashboard/doctor-list")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	
	<!-- active Doctor -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-success">
			<div class="inner">
				<h3><?php echo e($activeDoctorCount); ?></h3>
				<p>Active Doctor</p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-user-doctor"></i>
			</div>
			<a href="<?php echo e(url("dashboard/active-doctor")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
    
    <div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box" style="background: yellow">
			<div class="inner">
				<h3><?php echo e($inActiveDoctorCount); ?></h3>
				<p>Inactive Doctor</p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-user-doctor"></i>
			</div>
			<a href="<?php echo e(url("dashboard/inactive-doctor")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<!-- Today Doctor -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-success">
			<div class="inner">
				<h3><?php echo e($todayDoctorCount); ?></h3>
				<p>Today Registered <br> Doctor </p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-user-doctor"></i>
			</div>
		</div>
	</div>
	<!-- ./col -->
</div><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/dashboard/count/doctor.blade.php ENDPATH**/ ?>
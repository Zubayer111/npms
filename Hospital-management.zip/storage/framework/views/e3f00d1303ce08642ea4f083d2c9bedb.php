

<?php $__env->startSection("page_content"); ?>
    <?php if(session('type') == 'Admin'): ?>
        <?php echo $__env->make("backend.components.dashboard.profile.admin-profile", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(session('type') == 'Company'): ?>
        <?php echo $__env->make("backend.components.dashboard.profile.company-profile", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(session('type') == 'Doctor'): ?>
        <?php echo $__env->make("backend.components.dashboard.profile.doctor-profile", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(session('type') == 'Patient'): ?>
        <?php echo $__env->make("backend.components.dashboard.profile.patient-profile", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make("backend.layouts.sidenav-layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/pages/dashboard/profile-page.blade.php ENDPATH**/ ?>
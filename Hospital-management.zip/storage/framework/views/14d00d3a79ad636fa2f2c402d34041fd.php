<div class="hold-transition login-page">
    <div class="login-box">
        <!-- /.login-logo -->
        <div class="card card-outline card-primary">
          <div class="card-header text-center">
            <a href="../../index2.html" class="h1"><b>Admin</b>LTE</a>
          </div>
          <div class="card-body">
            <p class="login-box-msg">Sign in to start your session</p>
      
            <form action="<?php echo e(route("user-login")); ?>" method="post">
              <?php echo csrf_field(); ?>
              <div class="form-group col-md-12">
                <label for="exampleInputMobile">Mobile Number</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text">+88</span>
                    </div>
                    <input name="phone" type="number" class="form-control" value="<?php echo e(old('phone')); ?>" id="phone" placeholder="Enter mobile" required>
                    
                </div>
                <span id="result"></span>
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
            </div>
                
                
              
              <div class="row">
                <div class="col-8">
                  
                </div>
                <!-- /.col -->
                <div class="col-4">
                  <button id="submit" type="submit" class="btn btn-primary btn-block">Sign In</button>
                </div>
                <!-- /.col -->
              </div>
            </form>
      
            
            <!-- /.social-auth-links -->
      
            
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
<?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/auth/patient-login.blade.php ENDPATH**/ ?>
<div class="tab-pane" id="medical-info">
    <div class="timeline timeline-inverse">
        <section class="content">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header bg-info">
                            <h3 class="card-title">Info List</h3>
                            <div class="card-tools">
                                <div class="input-group input-group-sm">
                                    <div class="input-group-append">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="container-fluid">
                                <div class="row">
                                    <!-- Left Column with Health Indicators -->
                                    <div class="col-lg-5 col-md-5 col-sm-12" style="border-right: 2px solid #D4AF37; padding: 10px;">
                                        <div class="bg-info">
                                            <p class="text-bold text-white text-center">Patient Illness</p>
                                        </div>
                                        
                                        <div class="row" id="illness-list">
                                            <!-- This will be dynamically populated by AJAX -->
                                        </div>
                                        
                                        <hr style="border-top: 2px solid #D4AF37;">
                                        <?php if($diseases->isEmpty()): ?>
                                            <p>No data available</p>
                                        <?php else: ?>
                                            <div class="d-flex flex-wrap">
                                                <?php $__currentLoopData = $diseases->unique('disease_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="p-2">
                                                        <a href="javascript:void(0);" data-disease-id="<?php echo e($d->id); ?>" data-user-id="<?php echo e($data->user_id); ?>" class="text-bold btn btn-success btn-sm submit-ajax"><?php echo e($d->disease_name); ?></a>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php endif; ?>
                                        <input type="hidden" name="user_id" value="<?php echo e($data->id); ?>">
                                    </div>
                                    
                            
                                    <!-- Right Column with Table and Add Button -->
                                    <div class="col-lg-7 col-md-7 col-sm-12" style="padding: 20px;">
                                        <table id="complain_table" class="table table-bordered table-hover w-100">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Complain</th>
                                                    <th>Created By</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                
                                            </tbody>
                                        </table>
                            
                                        <!-- ADD Button -->
                                        <div style="text-align: right; margin-top: 20px;">
                                            <button type="button" id="addComplain" class="btn btn-primary btn-sm" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#addComplainModal">ADD</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>

            
        </section>
    </div>
</div>


<script type="text/javascript">
    $(document).ready(function() {
        var patientId = <?php echo e($data->user_id); ?>; 
        var url = "<?php echo e(route('dashboard.patient.complain-list', ':id')); ?>";
        url = url.replace(':id', patientId);

        $('#complain_table').DataTable({
            processing: true,
            serverSide: true,
            responsive: true,
            ajax: url,
            columns: [
                {data: 'id', name: 'id'},
                {data: 'complain', name: 'complain'},
                {data: 'created_by', name: 'created_by'},
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ],
            order: [[0, 'desc']],
            buttons: [
                'copyHtml5',
                'excelHtml5',
                'csvHtml5',
                'pdfHtml5'
            ]
        });
    });

  
      function confirmDelete(id) {
          Swal.fire({
              title: 'Delete User!',
              text: "Are you sure you want to delete?",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
              if (result.isConfirmed) {
                  document.getElementById('delete-form-' + id).submit();
              }
          })
      }

      $(document).ready(function() {
        // Handle adding a disease via AJAX
        $('.submit-ajax').on('click', function(e) {
            e.preventDefault(); // Prevent the default link behavior

            // Get the disease ID and user ID from the link's data attributes
            var diseaseId = $(this).data('disease-id');
            var userId = $(this).data('user-id');

            // Construct the URL using the diseaseId and userId
            var url = "<?php echo e(route('dashboard.add-patient-ilnase', [':id', ':pid'])); ?>";
            url = url.replace(':id', diseaseId).replace(':pid', userId);

            // Send the AJAX request to add the illness
            $.ajax({
                url: url, // The dynamically generated URL
                type: 'GET', // or 'POST' depending on your route's method
                success: function(response) {
                    // After success, reload the illness list
                    loadIllnessList(userId); // Call a function to reload the illness list
                },
                error: function(xhr) {
                    alert('Something went wrong. Please try again.');
                }
            });
        });

        // Function to load the illness list
        function loadIllnessList(userId) {
            // AJAX call to fetch the updated illness list
            $.ajax({
                url: '<?php echo e(route("dashboard.get-ilnase-list", ":id")); ?>'.replace(':id', userId),
                type: 'GET',
                success: function(response) {
                    if(response.status === "success") {
                        var illnessList = response.data;
                        var html = '';

                        if (illnessList.length > 0) {
                            // Loop through the data and generate the HTML dynamically
                            $.each(illnessList, function(index, illness) {
                                html += '<div class="p-2">';
                                html += '<a href="#" class="btn btn-danger btn-sm">' + illness.disease.disease_name + '</a>';
                                html += '</div>';
                            });
                        } else {
                            html = '<p>No data available</p>';
                        }

                        // Append the generated HTML to the illness-list div
                        $('#illness-list').html(html);
                    }
                },
                error: function(xhr) {
                    alert('Something went wrong while fetching the illness list.');
                }
            });
        }

        // Initial load of illness list when the page loads
        var patientId = <?php echo e($data->user_id); ?>; // Assuming you have the patient ID available
        loadIllnessList(patientId); // Load the illness list on page load
    });

    
    
</script><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/dashboard/profile/tab-content/patient/medicale-info/medical-info.blade.php ENDPATH**/ ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Profile</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">User Profile</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="card card-primary card-outline">
            <div class="card-body box-profile">
              <div class="text-center">
                <?php if($data && $data->profile_photo): ?>
                    <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset($data->profile_photo)); ?>" alt="User profile picture">
                <?php else: ?>
                    <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset('assets/dist/img/avatar.png')); ?>" alt="Default profile picture">
                <?php endif; ?>
              </div>
              
              <h3 class="profile-username text-center"><?php echo e($data->first_name ?? 'No user data available'); ?> <?php echo e($data->middle_name ?? ''); ?> <?php echo e($data->last_name ?? ''); ?></h3>

              <p class="text-muted text-center">Doctor</p>

              

              <a href="<?php echo e(route('dashboard.doctor.profile.edit')); ?>" class="btn btn-primary btn-block"><b>Edit</b></a>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

          <!-- About Me Box -->
          
          <!-- /.card -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="card">
            <div class="card-header p-2">
              <ul class="nav nav-pills">
                <li class="nav-item"><a class="nav-link active" href="#activity" data-toggle="tab">Basic Information</a></li>
                
                <li class="nav-item"><a class="nav-link" href="#settings" data-toggle="tab">Security</a></li>
              </ul>
            </div><!-- /.card-header -->
            <div class="card-body">
              <div class="tab-content">
                <div class="active tab-pane" id="activity">
                  <!-- Post -->
                  <div class="post">
                    <div class="user-block">
                      <div class="row">
                        <div class="col-md-6">
                          <h5 class="text-bold">First Name :</h5>
                          <p class="text-muted"><?php echo e($data->first_name ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Middile Name :</h5>
                          <p class="text-muted"><?php echo e($data->middle_name ?? "No user data available"); ?></p>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <h5 class="text-bold">Last Name :</h5>
                          <p class="text-muted"><?php echo e($data->last_name ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Email :</h5>
                          <p class="text-muted"><?php echo e($data->user->email ?? "No user data available"); ?></p>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <h5 class="text-bold">Phone :</h5>
                          <p class="text-muted"><?php echo e($data->phone_number ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Present Address :</h5>
                          <p class="text-muted"><?php echo e($data->address_one ?? "No user data available"); ?></p>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <h5 class="text-bold">Perment Address :</h5>
                        <p class="text-muted"><?php echo e($data->address_two ?? "No user data available"); ?></p>
                      </div>
                      <div class="col-md-6">
                        <h5 class="text-bold">City :</h5>
                        <p class="text-muted"><?php echo e($data->city ?? "No user data available"); ?></p>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <h5 class="text-bold">State :</h5>
                        <p class="text-muted"><?php echo e($data->state ?? "No user data available"); ?></p>
                      </div>
                      <div class="col-md-6">
                        <h5 class="text-bold">Zip Code :</h5>
                        <p class="text-muted"><?php echo e($data->zip_code ?? "No user data available"); ?></p>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <h5 class="text-bold">Degree :</h5>
                        <p class="text-muted"><?php echo e($data->degree ?? "No user data available"); ?></p>
                      </div>
                      <div class="col-md-6">
                        <h5 class="text-bold">Speciality :</h5>
                        <p class="text-muted"><?php echo e($data->speciality ?? "No user data available"); ?></p>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <h5 class="text-bold">Organization :</h5>
                        <p class="text-muted"><?php echo e($data->organization ?? "No user data available"); ?></p>
                      </div>
                      
                    </div>
                  </div>
                  
                </div>
                
                  <!-- /.post -->
                
                <!-- /.tab-pane -->
                
                <!-- /.tab-pane -->

                <div class="tab-pane" id="settings">
                  <form action="<?php echo e(route('dashboard.update-password')); ?>" class="form-horizontal" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                      <label for="inputName" class="col-sm-2 col-form-label">Password</label>
                      <div class="col-sm-10">
                        <input name="password" type="password" class="form-control" id="inputName" placeholder="Password" required>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputEmail" class="col-sm-2 col-form-label">Comfirm Password</label>
                      <div class="col-sm-10">
                        <input name="confirm_password" type="password" class="form-control" id="inputEmail" placeholder="Comfirm Password" required>
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="offset-sm-2 col-sm-10">
                        
                        <button type="submit" class="btn btn-primary float-right">Submit</button>

                      </div>
                    </div>
                  </form>
                </div>
                <!-- /.tab-pane -->
              </div>
              <!-- /.tab-content -->
            </div><!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div><!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/dashboard/profile/doctor-profile.blade.php ENDPATH**/ ?>
<div class="card-body box-profile">
    <div class="text-center">
        <?php if($data && $data->profile_photo): ?>
            <img class="profile-user-img img-fluid img-circle" style="height: 100px" src="<?php echo e(asset($data->profile_photo)); ?>" alt="User profile picture">
        <?php else: ?>
            <img class="profile-user-img img-fluid img-circle" style="height: 100px" src="<?php echo e(asset('assets/dist/img/image-not-found.png')); ?>" alt="Image not found">
        <?php endif; ?>
    </div>
    
    <h3 class="profile-username text-center">
        <?php echo e($data->first_name ?? 'No user data available'); ?> <?php echo e($data->middle_name ?? ''); ?> <?php echo e($data->last_name ?? ''); ?>

    </h3>

    <p class="text-muted text-center">Patient</p>
    <a href="<?php echo e(route('dashboard.patient.profile.edit')); ?>" class="btn btn-primary btn-block"><b>Edit</b></a>
</div><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/dashboard/profile/card/patient-card.blade.php ENDPATH**/ ?>
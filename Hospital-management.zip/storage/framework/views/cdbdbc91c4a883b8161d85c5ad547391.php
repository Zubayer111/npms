
<div class="modal fade" id="editGroupModal" tabindex="-1" role="dialog" aria-labelledby="createMedicineGroupModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-info">
                <h5 class="modal-title" id="createMedicineGroupModalLabel">Edit Medicine Group</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="editMedicineGroupForm" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="group_id" id="id">
                    <div class="form-group">
                        <label for="group_name">Medicine Group Name</label>
                        <input id="edit_group_name" name="group_name" type="text" class="form-control" value="<?php echo e(old('group_name')); ?>" placeholder="Enter group name" required>
                        <span id="groupNameError"></span>
                        <?php $__errorArgs = ['group_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="Status">Status</label>
                        <select name="status" id="edit_status" class="form-control" required>
                          <option value="" selected="selected">Select Status</option>
                          <option value="active">Active</option>
                          <option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="description">Medicine Group Description</label>
                        <textarea id="edit_description" name="description" class="form-control" placeholder="Enter description" required><?php echo e(old('description')); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="card-footer col-md-12 justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success float-right" id="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('#group_name').on('keyup', function() {
            var groupName = $(this).val();

            $.ajax({
                url: '<?php echo e(route("dashboard.check.group-name")); ?>',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    group_name: groupName
                },
                success: function(response) {
                    if (response.exists) {
                        $('#groupNameError').html('This medicine group name is already taken.').css('color', 'red');
                        $('#submit').attr('disabled', true);
                    } else {
                        
                        $('#groupNameError').html('');
                        $('#submit').attr('disabled', false);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error occurred:', error); 
                }
            });
        });
    });

    $(document).on('click', '#editBtn', function() {
    var url = $(this).data('url'); 
    $.ajax({
        url: url,
        type: 'GET',
        success: function(response) {
            if(response.status === 'success') {
                var group = response.data;
                $('#id').val(group.id);
                $('#edit_group_name').val(group.group_name);
                $('#edit_description').val(group.description);
                
                $('#edit_status').val(group.status).trigger('change');

                $('#editGroupModal').modal('show');
            }
        },
        error: function(xhr) {
            console.error("An error occurred: " + xhr.status + " " + xhr.statusText);
        }
    });
});
</script>

<script>
    $(document).ready(function() {
        $('#editMedicineGroupForm').on('submit', function(event) {
            event.preventDefault();

            var formData = {
                _token: '<?php echo e(csrf_token()); ?>',
                group_id: $('#id').val(),
                group_name: $('#edit_group_name').val(),
                status: $('#edit_status').val(),
                description: $('#edit_description').val()
            };

            $.ajax({
                url: '<?php echo e(route('dashboard.update.group')); ?>',
                method: 'POST',
                data: formData,
                success: function(response) {
                    if (response.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message,
                        });
                        setTimeout(function() {
                            window.location.href = '<?php echo e(route('dashboard.medicine-group-list')); ?>';
                        }, 2000);
                    }
                },
                error: function(xhr) {
                    let errors = xhr.responseJSON.errors;
                    let errorMessage = '';
                    for (let key in errors) {
                        errorMessage += errors[key][0] + '\n';
                    }
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: errorMessage,
                    });
                }
            });
        });
    });
</script>



<?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/medicine_group/edit-group.blade.php ENDPATH**/ ?>
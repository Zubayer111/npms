<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
    <div style="margin:50px auto;width:70%;padding:20px 0">
      <div style="border-bottom:1px solid #eee">
        <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Your Brand</a>
      </div>
      <p style="font-size:1.1em">Hi,</p>
      <p>Thank you for choosing Your Brand.</p>
      <h4>User Info</h4>
      <p>Name: <?php echo e($info['name']); ?></p>
      <p>Email: <?php echo e($info['email']); ?></p>
      <p>Password: <?php echo e($info['password']); ?></p>
      <hr style="border:none;border-top:1px solid #eee" />
      
    </div>
  </div><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/email/user-info.blade.php ENDPATH**/ ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Profile</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">User Profile</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
  
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">
  
            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <?php if($data && $data->profile_photo): ?>
                      <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset($data->profile_photo)); ?>" alt="User profile picture">
                  <?php else: ?>
                      <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset('assets/dist/img/avatar.png')); ?>" alt="Default profile picture">
                  <?php endif; ?>
                </div>
                
                <h3 class="profile-username text-center"><?php echo e($data->first_name ?? 'No user data available'); ?> <?php echo e($data->middle_name ?? ''); ?> <?php echo e($data->last_name ?? ''); ?></h3>
  
                <p class="text-muted text-center">Patient</p>
  
                
  
                <a href="<?php echo e(route('dashboard.patient.admin.profile.edit',['id' => $data->id])); ?>" class="btn btn-primary btn-block"><b>Edit</b></a>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
  
            <!-- About Me Box -->
            
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-9">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                    <li class="nav-item"><a class="nav-link active" href="#basic-information" data-toggle="tab">Basic Information</a></li>
                    <li class="nav-item"><a class="nav-link" href="#medical-document" data-toggle="tab">Medical Document</a></li>
                    <li class="nav-item"><a class="nav-link" href="#medical-info" data-toggle="tab">Medical Info</a></li>
                    <li class="nav-item"><a class="nav-link" href="#treatments" data-toggle="tab">Treatments</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="active tab-pane" id="activity">
                    <!-- Post -->
                    <div class="post">
                      <div class="user-block">
                        <div class="row">
                          <div class="col-md-6">
                            <h5 class="text-bold">First Name :</h5>
                            <p class="text-muted"><?php echo e($data->first_name ?? "No user data available"); ?></p>
                          </div>
                          <div class="col-md-6">
                            <h5 class="text-bold">Middile Name :</h5>
                            <p class="text-muted"><?php echo e($data->middle_name ?? "No user data available"); ?></p>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6">
                            <h5 class="text-bold">Last Name :</h5>
                            <p class="text-muted"><?php echo e($data->last_name ?? "No user data available"); ?></p>
                          </div>
                          <div class="col-md-6">
                            <h5 class="text-bold">Email :</h5>
                            <p class="text-muted"><?php echo e($data->user->email ?? "No user data available"); ?></p>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6">
                            <h5 class="text-bold">Phone :</h5>
                            <p class="text-muted"><?php echo e($data->phone_number ?? "No user data available"); ?></p>
                          </div>
                          <div class="col-md-6">
                            <h5 class="text-bold">Present Address :</h5>
                            <p class="text-muted"><?php echo e($data->address_one ?? "No user data available"); ?></p>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <h5 class="text-bold">Perment Address :</h5>
                          <p class="text-muted"><?php echo e($data->address_two ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">City :</h5>
                          <p class="text-muted"><?php echo e($data->city ?? "No user data available"); ?></p>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <h5 class="text-bold">State :</h5>
                          <p class="text-muted"><?php echo e($data->state ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Zip Code :</h5>
                          <p class="text-muted"><?php echo e($data->zipCode ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Reference Time:</h5>
                          <?php if($data): ?>
                              <p class="text-muted"><?php echo e($data->reference_time ? $data->reference_time->format('F d, Y') : "No user data available"); ?></p>
                          <?php else: ?>
                              <p class="text-muted">No user data available</p>
                          <?php endif; ?>
                      </div>
                      
                        <div class="col-md-6">
                          <h5 class="text-bold">Gender :</h5>
                          <p class="text-muted"><?php echo e($data->gender ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Marital Status :</h5>
                          <p class="text-muted"><?php echo e($data->marital_status ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Date of Birth:</h5>
                          <?php if($data && $data->dob): ?>
                              <p class="text-muted"><?php echo e($data->dob->format('F d, Y')); ?></p>
                          <?php else: ?>
                              <p class="text-muted">No user data available</p>
                          <?php endif; ?>
                      </div>
                      
                        <div class="col-md-6">
                          <h5 class="text-bold">Height :</h5>
                          <p class="text-muted"><?php echo e($data->height ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Weight :</h5>
                          <p class="text-muted"><?php echo e($data->weight ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">BMI :</h5>
                          <p class="text-muted"><?php echo e($data->bmi ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Blood Group :</h5>
                          <p class="text-muted"><?php echo e($data->blood_group ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Economical Status :</h5>
                          <p class="text-muted"><?php echo e($data->economical_status ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Smoking Status  :</h5>
                          <p class="text-muted"><?php echo e($data->smoking_status ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Alcoholed Status  :</h5>
                          <p class="text-muted"><?php echo e($data->alcohole_status ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">History :</h5>
                          <p class="text-muted"><?php echo e($data->history ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Employer Details :</h5>
                          <p class="text-muted"><?php echo e($data->employer_details ?? "No user data available"); ?></p>
                        </div>
                        <div class="col-md-6">
                          <h5 class="text-bold">Reference Note :</h5>
                          <p class="text-muted"><?php echo e($data->reference_note ?? "No user data available"); ?></p>
                        </div>
                      </div>
                    </div>
                    
                  </div>
                  
                    <!-- /.post -->
                  
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="medical-document">
                    <!-- The timeline -->
                    <div class="timeline timeline-inverse">
                      <section class="content">
                        <div class="card card-info">
                            <?php echo $__env->make("backend.components.dashboard.profile.tab-content.patient.medical-document", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                        </div>
                        </section>
                    </div>
                    
                  </div>
                  <div class="tab-pane" id="medical-info">
                    <!-- The timeline -->
                    <div class="timeline timeline-inverse">
                      <section class="content">
                        <div class="card card-info">
                            <?php echo $__env->make("backend.components.dashboard.profile.tab-content.patient.medicale-info.medical-info", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make("backend.components.dashboard.profile.tab-content.patient.medicale-info.add-complain", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        </section>
                    </div>
                  </div>
                  <div class="tab-pane" id="treatments">
                    <!-- The timeline -->
                    <div class="timeline timeline-inverse">
                      <section class="content">
                        <div class="card card-info">
                            <?php echo $__env->make("backend.components.dashboard.profile.tab-content.patient.treatments", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        </section>
                    </div>
                    
                  </div>
                  <!-- /.card -->
                  <!-- /.tab-pane -->
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
  
    <!-- /.content -->
  </div>
  
  <script>
    function confirmDelete(id) {
          Swal.fire({
              title: 'Delete Medical Document !',
              text: "Are you sure you want to delete?",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
              if (result.isConfirmed) {
                  document.getElementById('delete-form-' + id).submit();
              }
          })
      }
  </script>

<?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/patient/view-patient.blade.php ENDPATH**/ ?>
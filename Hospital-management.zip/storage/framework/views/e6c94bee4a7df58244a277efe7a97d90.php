

<?php $__env->startSection("page_content"); ?>
    <?php echo $__env->make("backend.components.medicine_group.inactive-group", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("backend.layouts.sidenav-layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/pages/medicine_group/inactive-group-page.blade.php ENDPATH**/ ?>
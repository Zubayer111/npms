<div class="active tab-pane" id="basic-information">
	<!-- Post -->
	<div class="post">
		<div class="user-block">
			<div class="row">
				<div class="col-md-6">
					<h5 class="text-bold">First Name :</h5>
					<p class="text-muted"><?php echo e($data->first_name ?? "No user data available"); ?></p>
				</div>
				<div class="col-md-6">
					<h5 class="text-bold">Middile Name :</h5>
					<p class="text-muted"><?php echo e($data->middle_name ?? "No user data available"); ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<h5 class="text-bold">Last Name :</h5>
					<p class="text-muted"><?php echo e($data->last_name ?? "No user data available"); ?></p>
				</div>
				<div class="col-md-6">
					<h5 class="text-bold">Email :</h5>
					<p class="text-muted"><?php echo e($data->user->email ?? "No user data available"); ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<h5 class="text-bold">Phone :</h5>
					<p class="text-muted"><?php echo e($data->phone_number ?? "No user data available"); ?></p>
				</div>
				<div class="col-md-6">
					<h5 class="text-bold">Present Address :</h5>
					<p class="text-muted"><?php echo e($data->address_one ?? "No user data available"); ?></p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<h5 class="text-bold">Perment Address :</h5>
				<p class="text-muted"><?php echo e($data->address_two ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">City :</h5>
				<p class="text-muted"><?php echo e($data->city ?? "No user data available"); ?></p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<h5 class="text-bold">State :</h5>
				<p class="text-muted"><?php echo e($data->state ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Zip Code :</h5>
				<p class="text-muted"><?php echo e($data->zipCode ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Reference Time:</h5> <?php if($data): ?> <p class="text-muted"><?php echo e($data->reference_time ? $data->reference_time->format('F d, Y') : "No user data available"); ?></p> <?php else: ?> <p class="text-muted">No user data available</p> <?php endif; ?>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Gender :</h5>
				<p class="text-muted"><?php echo e($data->gender ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Marital Status :</h5>
				<p class="text-muted"><?php echo e($data->marital_status ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Date of Birth:</h5> <?php if($data && $data->dob): ?> <p class="text-muted"><?php echo e($data->dob->format('F d, Y')); ?></p> <?php else: ?> <p class="text-muted">No user data available</p> <?php endif; ?>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Height :</h5>
				<p class="text-muted"><?php echo e($data->height ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Weight :</h5>
				<p class="text-muted"><?php echo e($data->weight ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">BMI :</h5>
				<p class="text-muted"><?php echo e($data->bmi ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Blood Group :</h5>
				<p class="text-muted"><?php echo e($data->blood_group ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Economical Status :</h5>
				<p class="text-muted"><?php echo e($data->economical_status ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Smoking Status :</h5>
				<p class="text-muted"><?php echo e($data->smoking_status ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Alcoholed Status :</h5>
				<p class="text-muted"><?php echo e($data->alcohole_status ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">History :</h5>
				<p class="text-muted"><?php echo e($data->history ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Employer Details :</h5>
				<p class="text-muted"><?php echo e($data->employer_details ?? "No user data available"); ?></p>
			</div>
			<div class="col-md-6">
				<h5 class="text-bold">Reference Note :</h5>
				<p class="text-muted"><?php echo e($data->reference_note ?? "No user data available"); ?></p>
			</div>
		</div>
	</div>
</div><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/dashboard/profile/tab-content/patient/basic-information.blade.php ENDPATH**/ ?>
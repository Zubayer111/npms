<!-- Create doctor Modal -->
<div class="modal fade" id="createUserModal" tabindex="-1" role="dialog" aria-labelledby="createUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-info">
                <h5 class="modal-title" id="createUserModalLabel">Create Patient</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Include your form here -->
                <form id="createUserForm" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body row">
                        <div class="form-group col-md-6">
                            <label for="exampleInputName">Name</label>
                            <input name="name" type="text" class="form-control" value="<?php echo e(old('name')); ?>" id="name" placeholder="Enter name" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                
                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1">Email address</label>
                            <input name="email" type="email" class="form-control" value="<?php echo e(old('email')); ?>" id="email" placeholder="Enter email" required>
                            <span id="email-availability-status"></span>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                
                        <div class="form-group col-md-6">
                          <label for="exampleInputMobile">Mobile Number</label>
                          <div class="input-group">
                              <div class="input-group-prepend">
                                  <span class="input-group-text">+88</span>
                              </div>
                              <input name="phone" type="number" class="form-control" value="<?php echo e(old('phone')); ?>" id="phone" placeholder="Enter mobile" required>
                          </div>
                          <span id="result"></span>
                          <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <p class="text-danger"><?php echo e($message); ?></p>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                
                        <div class="form-group col-md-6">
                            <label for="exampleInputPassword1">Password</label>
                            <input name="password" type="password" class="form-control" id="password" value="<?php echo e(old('password')); ?>" placeholder="Password" required>
                            <span id="passwordStrength" style="color: red;"></span>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                
                        <div class="form-group col-md-6">
                            <label>Role</label>
                            <select name="type" class="form-control select2" style="width: 100%;" required>
                                <option value="Patient" <?php echo e(old('type') == 'Patient' ? 'selected' : ''); ?>>Patient</option>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="card-footer col-md-12 justify-content-between">
                        <button type="button" class="close float-left" data-dismiss="modal" aria-label="Close" ><span class="btn btn-dark" aria-hidden="true">Cancel</span></button>
                        <button type="submit" class="btn btn-primary float-right" id="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
            $('#createUserForm').on('submit', function(event) {
                event.preventDefault();

                $.ajax({
                    url: '<?php echo e(route('dashboard.create-patient')); ?>',
                    method: 'POST',
                    data: $(this).serialize(),
                    success: function(response) {
                        if(response.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: response.message,
                            });
                            setTimeout(function() {
                                window.location.href = '<?php echo e(route('dashboard.patient-list')); ?>';
                            }, 2000);
                        } 
                        else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.message,
                            })
                        }
                    },
                    error: function(xhr) {
                        let errors = xhr.responseJSON.errors;
                        let errorMessage = 'Something went wrong. Please try again later.\n';
                        for (let key in errors) {
                            errorMessage += errors[key][0] + '\n';
                        }
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message,
                        });
                    }
                });
            });
        });
</script>
</script>
  <script>
  $(document).ready(function() {
    $('#email').on('keyup', function() {
        var email = $(this).val();
        var emailRegEx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
        if (email.length > 0) {
            if (!emailRegEx.test(email)) {
                $('#email-availability-status').html('<span class="text-danger">Invalid email format.</span>');
                $('#submit').prop('disabled', true);
            } else {
                $.ajax({
                    url: '<?php echo e(route('check.email')); ?>',
                    method: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        email: email
                    },
                    success: function(response) {
                        if (response.exists) {
                            $('#email-availability-status').html('<span class="text-danger">Email is already taken.</span>');
                            $('#submit').prop('disabled', true);
                        } else {
                            $('#email-availability-status').html('<span class="text-success">Email is available.</span>');
                            $('#submit').prop('disabled', false);
                        }
                    }
                });
            }
        } else {
            $('#email-availability-status').html('');
        }
    });
  });
  
  $(document).ready(function() {
    var debounceTimer;
    $('#phone').on('keyup', function() {
        clearTimeout(debounceTimer); 
        var phone = $(this).val();

        debounceTimer = setTimeout(function() { 
            $.ajax({
                url: '<?php echo e(route('check.phone')); ?>',
                type: 'POST',
                data: {
                    phone: phone,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                beforeSend: function() {
                    $('#result').html('<span class="text-info">Checking...</span>');
                    $('#submit').prop('disabled', true);
                },
                success: function(response) {
                    if (response.status === 'success') {
                        $('#result').html('<span class="text-success">Phone number is valid</span>');
                        $('#submit').prop('disabled', false);
                    } else if (response.status === 'exists') {
                        $('#result').html('<span class="text-danger">Phone number is already taken</span>');
                        $('#submit').prop('disabled', true);
                    } else {
                        $('#result').html('<span class="text-danger">Phone number is not valid</span>');
                        $('#submit').prop('disabled', true);
                    }
                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        }, 300); // Debounce time in milliseconds
    });
});

  
          
          $(document).ready(function() {
              $('#password').on('keyup', function() {
                  var password = $(this).val();
                  $.ajax({
                      url: '<?php echo e(route("dashboard.check-password-strength")); ?>',
                      type: 'GET',
                      data: { password: password },
                      success: function(response) {
                          var strengthText = "";
                          switch(response.strength) {
                              case 0:
                                  strengthText = "Minmum 8 characters";
                                  break;
                              case 1:
                                  strengthText = "Very Weak";
                                  break;
                              case 2:
                                  strengthText = "Weak";
                                  break;
                              case 3:
                                  strengthText = "Medium";
                                  break;
                              case 4:
                                  strengthText = "Strong";
                                  break;
                              case 5:
                                  strengthText = "Very Strong";
                                  break;
                              case 6:
                                  strengthText = "Minmum 8 characters";
                                  break;
                          }
                          $('#passwordStrength').text('Password Strength: ' + strengthText);
                      }
                  });
              });
          });
      
  </script>
  <?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/patient/create-patient.blade.php ENDPATH**/ ?>
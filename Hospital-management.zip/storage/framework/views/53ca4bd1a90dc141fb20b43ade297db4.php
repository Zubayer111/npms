<div class="hold-transition login-page">
    <div class="login-box">
        <div class="card card-outline card-primary">
          <div class="card-header text-center">
            <a href="../../index2.html" class="h1"><b>Admin</b>LTE</a>
          </div>
          <div class="card-body">
            <p class="login-box-msg">Veryfy Your OTP</p>
            <form action="<?php echo e(route("patient-verify-otp")); ?>" method="post">
              <?php echo csrf_field(); ?>
              <div class="input-group mb-3">
                <input name="otp" type="number" class="form-control" placeholder="Otp" required>
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-envelope"></span>
                  </div>
                </div>
                <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="row">
                <div class="col-12">
                  <button type="submit" class="btn btn-primary btn-block">Submit</button>
                </div>
                <!-- /.col -->
              </div>
            </form>
            <p class="mt-3 mb-1">
              <a href="<?php echo e(url("/user-login")); ?>">Login</a>
            </p>
          </div>
          <!-- /.login-card-body -->
        </div>
      </div>
    </div><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/auth/patient-verify-otp.blade.php ENDPATH**/ ?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Update Doctor Profile Form</h1>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Update Doctor Profile</li>
              </ol>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Update Doctor Profile</h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <form action="<?php echo e(route('dashboard.doctor.profile.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card-body row">
                <div class="form-group col-md-6">
                    <div class="form-group">
                        <label for="exampleInputFile">File input</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input name="profile_photo" type="file" value="<?php echo e($user->profile_photo ?? ''); ?>" class="custom-file-input" id="exampleInputFile" required>
                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                          </div>
                          <div class="input-group-append">
                            <span class="input-group-text">Upload</span>
                          </div>
                        </div>
                      </div>
                </div>
                <div class="text-center">
                  <?php if($user && $user->profile_photo): ?>
                      <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset($user->profile_photo)); ?>" alt="User profile picture">
                  <?php else: ?>
                      
                  <?php endif; ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="exampleInputName">First Name</label>
                    <input name="first_name" type="text" class="form-control" id="exampleInputName" placeholder="Enter first name" value="<?php echo e($user->first_name ?? ''); ?>" required>
                </div>
                    
                
                <div class="form-group col-md-6">
                    <label for="exampleInputEmail1">Middle Name</label>
                    <input name="middle_name" type="text" class="form-control" id="exampleInputName" placeholder="Enter middle name" value="<?php echo e($user->middle_name ?? ''); ?>" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="exampleInputMobile">Last Name</label>
                  <input name="last_name" type="text" class="form-control" id="exampleInputMobile" placeholder="Enter last name" value="<?php echo e($user->last_name ?? ''); ?>" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="exampleInputMobile">Mobile Number</label>
                  <div class="input-group">
                      <div class="input-group-prepend">
                          <span class="input-group-text">+88</span>
                      </div>
                      <input name="phone_number" type="number" class="form-control" value="<?php echo e($user->phone_number ?? ''); ?>" id="phone" placeholder="Enter mobile"  required>
                  </div>
                  <span id="result"></span>
                  <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
                <div class="form-group col-md-6">
                    <label for="exampleInputName">Present Address</label>
                    <input name="address_one" type="text" class="form-control" id="exampleInputName" placeholder="Enter present address" value="<?php echo e($user->address_one ?? ''); ?>" required>
                </div>
                    
                
                <div class="form-group col-md-6">
                    <label for="exampleInputEmail1">Permanent Address</label>
                    <input name="address_two" type="text" class="form-control" id="exampleInputName" placeholder="Enter permanent address" value="<?php echo e($user->address_two ?? ''); ?>" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="exampleInputMobile">City</label>
                  <input name="city" type="text" class="form-control" id="exampleInputMobile" placeholder="Enter city" value="<?php echo e($user->city ?? ''); ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="exampleInputMobile">State</label>
                    <input name="state" type="text" class="form-control" id="exampleInputMobile" placeholder="Enter state" value="<?php echo e($user->state ?? ''); ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="exampleInputMobile">Zip Code</label>
                    <input name="zip_code" type="text" class="form-control" id="exampleInputMobile" placeholder="Enter zip code" value="<?php echo e($user->zip_code ?? ''); ?>" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="exampleInputMobile">Degree</label>
                  <input name="degree" type="number" class="form-control" id="exampleInputMobile" placeholder="Enter city" value="<?php echo e($user->degree ?? ''); ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="exampleInputMobile">Speciality</label>
                    <input name="speciality" type="text" class="form-control" id="exampleInputMobile" placeholder="Enter state" value="<?php echo e($user->speciality ?? ''); ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="exampleInputMobile">Organization</label>
                    <input name="organization" type="text" class="form-control" id="exampleInputMobile" placeholder="Enter zip code" value="<?php echo e($user->organization ?? ''); ?>" required>
                </div>
            </div>
            
          <!-- /.card-body -->
          
          
          <div class="card-footer col-md-12 justify-content-between">
            <button type="button" class="btn btn-secondary" onclick="window.location.href='<?php echo e(url('dashboard/profile')); ?>'">Cancel</button>
            <button type="submit" class="btn btn-primary float-right" id="submit">Submit</button>
        </div>
        </form>
        
      </div>
      </section>
</div>    

<script>
  $(document).ready(function() {
            $('#phone').on('keyup', function() {
                var phone = $(this).val();

                $.ajax({
                    url: '<?php echo e(route('check.phone')); ?>',
                    type: 'POST',
                    data: {
                        phone: phone,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        if (response.status === 'success') {
                            $('#result').html('<span class="text-success">Phone number is valid</span>');
                            $('#submit').prop('disabled', false);
                        } else {
                            $('#result').html('<span class="text-danger">Phone number is not valid</span>');
                            $('#submit').prop('disabled', true);
                        }
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
            });
        });
</script><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/dashboard/profile/edit/doctor-profile-edit.blade.php ENDPATH**/ ?>
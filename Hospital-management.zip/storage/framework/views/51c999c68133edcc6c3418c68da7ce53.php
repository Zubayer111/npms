<div class="row">
	<!-- Admin -->
	<div class="col-lg-3 col-6">
		<div class="small-box bg-info">
			<div class="inner">
				<h3><?php echo e($adminCount); ?></h3>
				<p>Admin</p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-user-tie"></i>
			</div>
			<a href="<?php echo e(url("dashboard/admin-list")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<!-- active Admin -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-info">
			<div class="inner">
				<h3><?php echo e($activeAdminCount); ?></h3>
				<p>Active Admin</p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-user-tie"></i>
			</div>
			<a href="<?php echo e(url("dashboard/active-admin")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<!-- Doctor -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-success">
			<div class="inner">
				<h3><?php echo e($doctorCount); ?></h3>
				<p>Doctor</p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-user-doctor"></i>
			</div>
			<a href="<?php echo e(url("dashboard/doctor-list")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<!-- active Doctor -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-success">
			<div class="inner">
				<h3><?php echo e($activeDoctorCount); ?></h3>
				<p>Active Doctor</p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-user-doctor"></i>
			</div>
			<a href="<?php echo e(url("dashboard/active-doctor")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<!-- Today Doctor -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-success">
			<div class="inner">
				<h3><?php echo e($todayDoctorCount); ?></h3>
				<p>Today Registered <br> Doctor </p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-user-doctor"></i>
			</div>
			
		</div>
	</div>
	<!-- Patient -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-warning">
			<div class="inner">
				<h3><?php echo e($patientCount); ?></h3>
				<p>Patient</p>
			</div>
			<div class="icon">
				<i class="ion ion-person-add"></i>
			</div>
			<a href="<?php echo e(url("dashboard/patient-list")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<!-- Today Patient -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-warning">
			<div class="inner">
				<h3><?php echo e($todayPatientCount); ?></h3>
				<p>Today Registered <br> Patient </p>
			</div>
			<div class="icon">
				<i class="ion ion-person-add"></i>
			</div>
			
		</div>
	</div>
	<!-- Company -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-danger">
			<div class="inner">
				<h3><?php echo e($companyCount); ?></h3>
				<p>Company</p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-building"></i>
			</div>
			<a href="<?php echo e(url("dashboard/company-list")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<!-- active Company -->
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-danger">
			<div class="inner">
				<h3><?php echo e($activeCompanyCount); ?></h3>
				<p> Active Company</p>
			</div>
			<div class="icon">
				<i class="fa-solid fa-building"></i>
			</div>
			<a href="<?php echo e(url("dashboard/active-company")); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<!-- ./col -->
</div><?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/dashboard/counter.blade.php ENDPATH**/ ?>
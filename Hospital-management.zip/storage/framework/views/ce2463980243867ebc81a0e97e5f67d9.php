<?php $__empty_1 = true; $__currentLoopData = $allPrescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td class="text-center text-sm"><?php echo e($loop->iteration); ?></td>
    <td class="text-sm"><?php echo e($m->name); ?></td> <!-- Use $m->name for the medicine name -->
    <td class="text-sm"><?php echo e($m->attributes->dose); ?></td> <!-- Access custom attributes -->
    <td class="text-sm"><?php echo e($m->attributes->duration); ?> <?php echo e($m->attributes->duration_unit); ?></td> <!-- Include duration unit -->
    <td class="text-sm"><?php echo e($m->attributes->instruction); ?></td>
    <td>
        <a href="#" class="btn btn-danger btn-sm delete-medicine" data-id="<?php echo e($m->id); ?>">
            <i class="fa-solid fa-trash"></i>
        </a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
    <td colspan="6" class="text-center">No medicines added.</td>
</tr>
<?php endif; ?>


<script>
 $(document).on('click', '.delete-medicine', function (e) {
    e.preventDefault();

    let medicineId = $(this).data('id'); // Retrieve the medicine ID

    $.ajax({
        url: '<?php echo e(route('dashboard.remove-prescritions-medicine')); ?>', // Endpoint for the remove action
        type: 'POST',
        data: {
            id: medicineId,
            _token: $('meta[name="csrf-token"]').attr('content') // Include the CSRF token
        },
        success: function (response) {
            $('#medicineList').html(response.html);
        },
        error: function (xhr, status, error) {
            console.error('AJAX error: ', error);
            alert('An error occurred. Please try again.');
        }
    });
});



</script>
<?php /**PATH D:\Ostad\project\Hospital-management\resources\views/backend/components/prescriptions/table/medicine-list.blade.php ENDPATH**/ ?>